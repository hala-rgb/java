package telechargementFichier;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;


public class Fich {
	
	

	//public class Demo {
		//Define global variable address
			static String address = "https://www.orafaq.com/forum/fa/9832/";
			
			public static void main(String[] args) {
				//Open three threads to download
				downloadFile(3);
			}
			
			/**
			 * Function: calculate the starting location of each thread download and execute the download.
			 * @param Thread count
			 */
			public static void downloadFile(int threadCount){
				
				try {
					URL url = new URL(address);
					HttpURLConnection conn = (HttpURLConnection) url.openConnection();
					conn.setConnectTimeout(5000);
					conn.setReadTimeout(5000);
					//Get the total size of File Bytes
					int fileLength = conn.getContentLength();
					System.out.println("Total file size:"+fileLength/1024/1024+"MB");
					int code = conn.getResponseCode();
					if (code == 200) {
						//Allocate "average" download bytes per thread
						int blockSize = fileLength/threadCount;
						//Create a random access stream to locally occupy files
						RandomAccessFile raf = new RandomAccessFile("mytext", "rw");
						//Important: assume that the file is only 10 bytes, download it in 3 threads, and understand the for loop code
						for (int threadId = 0; threadId < threadCount; threadId++) {
							int startIndex = threadId*blockSize;
							int endIndex = (threadCount+1)*blockSize-1;
							if (threadId == threadCount) {
								endIndex = fileLength - 1;
							}
							//Once per cycle, start a thread to perform the download. Do not miss start().
							new ThreadDownload(threadId, startIndex, endIndex).start();;
						}
						conn.disconnect();
					}else{
						System.out.println("Request failed, server response code:"+code);
					}
				} catch (MalformedURLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			
			/**
			 * Function: enable thread download and download the allocated file length
			 * @author Administrator
			 * @param Thread ID, Download start position, end position,
			 */
			public static class ThreadDownload extends Thread{
				private int threadId;
				private int startIndex;
				private int endIndex;
				
				//The constructor receives three parameters to initialize local variables: thread ID, start position and end position
				public ThreadDownload(int threadId, int startIndex, int endIndex) {
					this.threadId = threadId;
					this.startIndex = startIndex;
					this.endIndex = endIndex;	
				}
			
				@Override
				public void run(){
					try {
						URL url = new URL(address);
						HttpURLConnection conn = (HttpURLConnection) url.openConnection();
						conn.setConnectTimeout(5000);
						conn.setReadTimeout(5000);
						System.out.println("thread"+threadId+"Download start location"+startIndex+" End position:"+endIndex);
						
						//Set request header and request some resources to download
						conn.setRequestProperty("Range", "bytes:"+startIndex+"-"+endIndex);
						//Server response code 206 indicates that some resources are successfully requested
						if (conn.getResponseCode()==206) {
							InputStream inputStream = conn.getInputStream();
							RandomAccessFile raf = new RandomAccessFile(new File("mytext"), "rw");
							//Find write start position
							raf.seek(startIndex);
							byte array[] = new byte[1024];
							int len = -1;
							while((len = inputStream.read(array))!=-1){
								raf.write(array, 0, len);
							}
							inputStream.close();
							raf.close();
							conn.disconnect();
						}else{
							System.out.println("Server response code:"+conn.getResponseCode());
						}
					} catch (MalformedURLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
	}



