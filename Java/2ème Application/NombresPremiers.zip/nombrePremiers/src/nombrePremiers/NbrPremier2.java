package nombrePremiers;

import nombrePremiers.NbrPremier2.Thread1;
import  nombrePremiers.NbrPremier2.Thread2;
import nombrePremiers.NbrPremier2.Thread3;
import  nombrePremiers.NbrPremier2.Thread4;

public class NbrPremier2 {
	 public static int nbr;
	 public static int count=0;
	 
	  public static class Thread1  implements Runnable{

	        @Override
	        public void run() {
	        	int m= (int )(nbr/4);
	        	for(int i = 2; i<= m;){
	                int premier = 1;
	                for(int loop = 2; loop <=i; loop++) {
	                   if((i % loop) == 0 && loop!=i) {
	                      premier = 0;
	                   }
	                }
	                if (premier != 0){
	                   System.out.println(i+" est un nombre premier " + Thread.currentThread().getName());
	                   count++;
	                   i++;
	                }
	                else
	                i ++;
	             }
	          }
	    }
	  
	  public static class Thread2  implements Runnable {

	        @Override
	        public void run() {
	         int k= (int )(nbr/4)+1;
	         int m=(int)(nbr/2);
	        	for(int i = k; i<= m;){
	                int premier = 1;
	                for(int loop = 2; loop <=i; loop++) {
	                   if((i % loop) == 0 && loop!=i) {
	                      premier = 0;
	                   }
	                }
	                if (premier != 0){
	                   System.out.println(i+" est un nombre premier " + Thread.currentThread().getName());
	                   i++;
	                   count++;
	                }
	                else
	                i ++;
	             }
	          }
	    }
	  public static class Thread3  implements Runnable{

	        @Override
	        public void run() {
	         int k= (int )((nbr/4)*2 +1);
	         int m=(nbr/4)*3;
	        	for(int i = k; i<= m;){
	                int premier = 1;
	                for(int loop = 2; loop <=i; loop++) {
	                   if((i % loop) == 0 && loop!=i) {
	                      premier = 0;
	                   }
	                }
	                if (premier != 0){
	                   System.out.println(i+" est un nombre premier " + Thread.currentThread().getName());
	                   i++;
	                   count++;
	                }
	                else
	                i ++;
	             }
	          }
	    }
	  public static class Thread4  implements Runnable {

	        @Override
	        public void run() {
	         int k= ((nbr/4)*3 +1);
	         int m=nbr;
	        	for(int i = k; i<= m;){
	                int premier = 1;
	                for(int loop = 2; loop <=i; loop++) {
	                   if((i % loop) == 0 && loop!=i) {
	                      premier = 0;
	                   }
	                }
	                if (premier != 0){
	                   System.out.println(i+" est un nombre premier " + Thread.currentThread().getName());
	                   i++;
	                   count++;
	                }
	                else
	                i ++;
	             }
	          }
	    }

	    public static void main(String[] args) throws Exception {
	        long t1 = System.currentTimeMillis();
	        nbr=100;
	        Thread m1 = new Thread(new Thread1(), "m1");
	        Thread m2 = new Thread(new Thread2(), "m2");
	        Thread m3 = new Thread(new Thread3(), "m3");
	        Thread m4 = new Thread(new Thread4(), "m4");
	        m1.start();
	        m2.start();
	        m3.start();
	        m4.start();
	        m1.join();
	        m2.join();
	        m3.join();
	        m4.join();
	     
	        long t2 = System.currentTimeMillis();
	        System.out.println("the time is "+(t2-t1));
	        System.out.println("le nombre des nombres premiers est "+ count);

	    }
}
