package produitMtr;
import java.io.BufferedReader;
import java.io.FileInputStream;
	import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
	import java.sql.Time;
	import java.util.Scanner;
	import java.util.Timer;
	import java.util.concurrent.TimeUnit;
	import java.util.logging.Level;
	import java.util.logging.Logger;

	
	public class MatricesProduit {

	    public static int[][] c;
	    public static int[][] a;
	    public static int[][] b;

	    public static int[][] loadMatrix(int nbrrows, int nbrcols,String filename) throws Exception {
	    	//FileOutputStream sortie = new FileOutputStream(filename);
	    	
	    
	    	 PrintWriter pw = new PrintWriter(new FileOutputStream(filename));
	        int mat[][] = new int[nbrrows][nbrcols];
	        for (int i = 0; i < nbrrows; i++) {
	            for (int j = 0; j < nbrcols; j++) {
	                mat[i][j] = (int) (1 + (Math.random() * (100- 1)));
	                pw.print(mat[i][j] + "    ");
	            	
	            }
	            pw.println();

	        }
	        pw.close();
	        return mat;
	    }

	    

  public static void displayMatrix(int c[][]) throws Exception {
	        int rows = c.length;
	        int cols = c[0].length;
          System.out.println("rows   " + rows + "      columns     " + cols);

	        for (int i = 0; i < rows; i++) {
	            for (int j = 0; j < cols; j++) {
	                System.out.print(c[i][j] + "    ");

	            }
	            System.out.println();
	        }


	    }

	    public static class Thread1 extends Thread {

	        @Override
	        public void run() {
	            int m = a.length;
	            int n = b[0].length;
	            int k = (a.length) / 4;



	            for (int i = 0; i <= k; i++) {
	                for (int j = 0; j < n; j++) {
	                	c[i][j]=0;
	                    for (int l = 0; l < b.length; l++) {
	                        c[i][j] = c[i][j] + a[i][l] * b[l][j];

	                    }

	                }

	            }
	        }
	    }

	    public static class Thread2 extends Thread {

	        @Override
	        public void run() {
	            int m = a.length;
	            int n = b[0].length;
	            int k = (a.length) / 2+1;
	            int s = ((a.length) /4)+1;



	            for (int i = s ; i < k; i++) {
	                for (int j = 0; j < n; j++) {
	                 	c[i][j]=0;
	                    for (int l = 0; l < b.length; l++) {
	                        c[i][j] = c[i][j] + a[i][l] * b[l][j];

	                    }

	                }

	            }
	        }
	    }
	     public static class Thread3 extends Thread {

	        @Override
	        public void run() {
	            int m = a.length;
	            int n = b[0].length;
	            int k = ((3*(a.length))/4)+ 1;
	            int s = (a.length) / 2 + 1;



	            for (int i = s ; i < k; i++) {
	                for (int j = 0; j < n; j++) {
	                 	c[i][j]=0;
	                    for (int l = 0; l < b.length; l++) {
	                        c[i][j] = c[i][j] + a[i][l] * b[l][j];

	                    }

	                }

	            }
	        }
	    }
	      public static class Thread4 extends Thread {

	        @Override
	        public void run() {
	            int m = a.length;
	            int n = b[0].length;
	            int k = ((3*(a.length))/4)+ 1;



	            for (int i = k ; i < m; i++) {
	                for (int j = 0; j < n; j++) {
	                 	c[i][j]=0;
	                    for (int l = 0; l < b.length; l++) {
	                        c[i][j] = c[i][j] + a[i][l] * b[l][j];

	                    }

	                }

	            }
	        }
	    }

	    public static void main(String[] args) throws Exception {
	        long t1 = System.currentTimeMillis();
	        a = loadMatrix(100,100,"a.txt");
	        b = loadMatrix(100,100,"b.txt");
	        c= new int [a.length][b[0].length];

	        Thread1 m1 = new Thread1();
	        Thread2 m2 = new Thread2();
	        Thread3 m3 = new Thread3();
	        Thread4 m4 = new Thread4();
	        m1.start();
	        m2.start();
	        m3.start();
	        m4.start();
	        m1.join();
	        m2.join();
	        m3.join();
	        m4.join();
	        
	         displayMatrix(c);
	        long t2 = System.currentTimeMillis();
	        System.out.println("the time is "+(t2-t1));

	    }
	}


