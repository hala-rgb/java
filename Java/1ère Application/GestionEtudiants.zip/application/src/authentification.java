import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.ImageIcon;
import javax.swing.JTextField;



import javax.swing.JPasswordField;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import java.awt.event.WindowEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Statement;
import javax.swing.table.DefaultTableModel;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author wiam
 */
public class authentification extends JFrame{
    
    private JFrame frame;
	private JTextField usernamefield;
	private JPasswordField passwordfield;
    private JPanel jpane;
    //Création de 3 objets importants (cnx,prepared,resultat) :
    
    
    
    
    PreparedStatement prepared = null; //Classe qui permet de préparer une requête à l'exécution.
    ResultSet resultat = null; // Classe qui prend le résultat.
    
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					authentification window = new authentification();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public authentification() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 566, 426);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
                
		
		
		
		
		usernamefield = new JTextField();
		usernamefield.setBounds(259, 108, 191, 23);
		frame.getContentPane().add(usernamefield);
		usernamefield.setColumns(10);
		
		passwordfield = new JPasswordField();
		passwordfield.setBounds(259, 158, 191, 23);
		frame.getContentPane().add(passwordfield);
		
		JLabel lblNewLabel_1 = new JLabel("Entrez votre ID :");
		lblNewLabel_1.setFont(new Font("Cambria", Font.BOLD, 14));
		lblNewLabel_1.setForeground(Color.BLACK);
		lblNewLabel_1.setBounds(117, 102, 147, 33);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Mot de passe :");
		lblNewLabel_2.setFont(new Font("Cambria", Font.BOLD, 14));
		lblNewLabel_2.setForeground(Color.BLACK);
		lblNewLabel_2.setBounds(134, 159, 119, 18);
		frame.getContentPane().add(lblNewLabel_2);
		
		JButton btnNewButton = new JButton("Se connecter");
		btnNewButton.setFont(new Font("Cambria", Font.BOLD, 14));
		btnNewButton.setForeground(Color.BLACK);
                
                
                
                btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			//
                        
                        
                Connecter con=new Connecter();
                Statement stm;
                DefaultTableModel model=new DefaultTableModel();
                try {
stm=con.obtenirconnexion().createStatement();
ResultSet Rs=stm.executeQuery("SELECT * FROM etudiant");
while(Rs.next()){
model.addRow(new Object[]{Rs.getString("id"),Rs.getString("mot_de_passe")});

}
}catch(Exception a){System.err.println(a);}
                        
                        
	     	String id = usernamefield.getText().toString();
			String mot_de_passe = passwordfield.getText().toString();
				
			String sql = "SELECT id,mot_de_passe FROM etudiant";
			try {
				
			//	prepared = con.stm(sql);
				resultat = prepared.executeQuery();
				
				int i = 0;
				if(id.equals("") || mot_de_passe.equals("") )
				{
					JOptionPane.showMessageDialog(null, "Veuillez remplir les champs vides ! ");
					
				}else
				{				
				     while(resultat.next())
				{
					String username1 = resultat.getString("id");
					String password1 = resultat.getString("mot_de_passe");

					if (username1.equals(id) && password1.equals(mot_de_passe))
					{
						JOptionPane.showMessageDialog(null,"Connexion réussie. Bienvenue à vous ! :)");
						i = 1;
						
					}
				}
				if (i==0)
					JOptionPane.showMessageDialog(null,"Connexion échouée :( Veuillez réessayer.");
				}
			} catch (SQLException e1) {
//
				e1.printStackTrace();
			}
			
			}
		});
        }}
    

